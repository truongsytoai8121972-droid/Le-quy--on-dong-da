WEBSITE LOP 10A4 - THPT LE QUY DON

DEPLOY NETLIFY TU DONG TU GITHUB
1. Tai len GitHub hai tep trong goi nay: index.html va netlify.toml (dat o thu muc goc repository).
2. Vao Netlify > Add new project > Import an existing project > GitHub.
3. Chon repository: truongsytoai8121972-droid/Le-quy--on-dong-da.
4. Branch: main. Build command: de trong. Publish directory: .
5. Deploy. Sau do moi commit/push len nhanh main se tu dong kich hoat deploy moi.

Luu y:
- Goi nay chua duoc tu dong ghi vao GitHub vi chua co quyen truy cap/uy quyen tai khoan.
- Demo dang dung localStorage: thong bao va tin nhan chi luu tren trinh duyet thiet bi do, chua dong bo giua nhieu nguoi dung.
- Mat khau quan tri demo trong HTML khong phai bao mat thuc te; khong dung de bao ve du lieu rieng tu.
- Thoi khoa bieu mau can duoc doi chieu voi lich chinh thuc cua lop.
